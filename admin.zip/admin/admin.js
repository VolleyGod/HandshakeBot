const Discord = require("discord.js");
const client = new Discord.Client();
const fs = require("fs")
client.login("MjgyNTc5OTU1ODY1MzU0MjQw.DCA42w._SK_9SxoGAiICn5_2mohw_kcpJg");

client.on('ready', () => {
  console.log('I am ready!');
  
  client.on('message', message => {
  if (message.content === '*newrole') {
  client.on('roleCreate', roleCreate=> {
      guild.createRole({
  name: 'Super Cool People',
  color: 'BLUE',
})
.then(role => console.log(`Created role ${role}`))
.catch(console.error)
  
client.on('message', message => {
if (message.content.startsWith("*kick")) {
    let userToKick = message.mentions.users.first();
    message.guild.member(userToKick).kick();
    message.reply('Look what you have done to' + userToKick + userToKick.avatarURL); };
});
client.on('message', message => {
  if (message.content.startsWith("*ban")) {
    let userToBan = message.mentions.users.first();
    message.guild.member(userToBan).ban(1);
    message.reply(`Look what you've done to ` + userToBan + '!' + userToBan.avatarURL)
  }
})
client.on('guildMemberAdd', (member) => {
  console.log(`New User '${member.user.username}' has joined '${member.guild.name}'` );
client.channels.get('ID').send(`'${member.user.username}' has joined this server`);
})})}})});